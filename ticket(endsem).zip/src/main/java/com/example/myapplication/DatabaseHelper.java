package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "TicketBooking.db";
    public static final String TABLE_NAME = "tickets";
    public static final String COL_1 = "ID";
    public static final String COL_2 = "NAME";
    public static final String COL_3 = "TICKET_COUNT";
    public static final String COL_4 = "TYPE";
    public static final String COL_5 = "DATE";
    public static final String COL_6 = "PREFERENCE";
    public static final String COL_7 = "TOTAL_COST";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, TICKET_COUNT INTEGER, TYPE TEXT, DATE TEXT, PREFERENCE TEXT, TOTAL_COST DOUBLE)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public long insertData(String name, int tickets, String type, String date, String pref, double cost) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2, name);
        contentValues.put(COL_3, tickets);
        contentValues.put(COL_4, type);
        contentValues.put(COL_5, date);
        contentValues.put(COL_6, pref);
        contentValues.put(COL_7, cost);
        return db.insert(TABLE_NAME, null, contentValues);
    }

    public Cursor getAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("select * from " + TABLE_NAME + " ORDER BY ID DESC LIMIT 1", null);
    }

    public boolean updateData(String id, String name, int tickets, String type, String date, String pref, double cost) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2, name);
        contentValues.put(COL_3, tickets);
        contentValues.put(COL_4, type);
        contentValues.put(COL_5, date);
        contentValues.put(COL_6, pref);
        contentValues.put(COL_7, cost);
        db.update(TABLE_NAME, contentValues, "ID = ?", new String[]{id});
        return true;
    }
}