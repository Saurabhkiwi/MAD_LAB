package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText etName, etTickets;
    Spinner spinnerType;
    DatePicker datePicker;
    RadioGroup rgSeat;
    Button btnBook;
    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        etTickets = findViewById(R.id.etTickets);
        spinnerType = findViewById(R.id.spinnerType);
        datePicker = findViewById(R.id.datePicker);
        rgSeat = findViewById(R.id.rgSeat);
        btnBook = findViewById(R.id.btnBook);
        dbHelper = new DatabaseHelper(this);

        String[] types = {"Bus", "Train"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, types);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerType.setAdapter(adapter);

        btnBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bookTicket();
            }
        });
    }

    private void bookTicket() {
        String name = etName.getText().toString();
        String ticketsStr = etTickets.getText().toString();

        if (name.isEmpty() || ticketsStr.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        int tickets = Integer.parseInt(ticketsStr);
        String type = spinnerType.getSelectedItem().toString();
        String date = datePicker.getDayOfMonth() + "/" + (datePicker.getMonth() + 1) + "/" + datePicker.getYear();

        int selectedId = rgSeat.getCheckedRadioButtonId();
        if (selectedId == -1) {
            Toast.makeText(this, "Select seat preference", Toast.LENGTH_SHORT).show();
            return;
        }
        RadioButton rb = findViewById(selectedId);
        String pref = rb.getText().toString();

        double prefCost = pref.equals("Window") ? 50.0 : 30.0;
        double totalCost = tickets * prefCost;

        long id = dbHelper.insertData(name, tickets, type, date, pref, totalCost);

        if (id != -1) {
            Toast.makeText(this, "Total Cost: " + totalCost, Toast.LENGTH_LONG).show();
            Intent intent = new Intent(MainActivity.this, SummaryActivity.class);
            intent.putExtra("ID", String.valueOf(id));
            startActivity(intent);
        } else {
            Toast.makeText(this, "Error inserting data", Toast.LENGTH_SHORT).show();
        }
    }
}