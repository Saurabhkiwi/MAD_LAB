package com.example.myapplication;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SummaryActivity extends AppCompatActivity {

    EditText etSumName;
    TextView tvDetails;
    Button btnEditUpdate, btnSubmitFinal;
    DatabaseHelper dbHelper;
    String ticketId;

    // Storing other values to use in update
    int tickets;
    String type, date, pref;
    double cost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        etSumName = findViewById(R.id.etSumName);
        tvDetails = findViewById(R.id.tvDetails);
        btnEditUpdate = findViewById(R.id.btnEditUpdate);
        btnSubmitFinal = findViewById(R.id.btnSubmitFinal);
        dbHelper = new DatabaseHelper(this);

        ticketId = getIntent().getStringExtra("ID");
        loadData();

        btnEditUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newName = etSumName.getText().toString();
                boolean isUpdated = dbHelper.updateData(ticketId, newName, tickets, type, date, pref, cost);
                if (isUpdated) {
                    Toast.makeText(SummaryActivity.this, "Data Updated in Database", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(SummaryActivity.this, "Update Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnSubmitFinal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(SummaryActivity.this, "Final Submission Successful", Toast.LENGTH_LONG).show();
                finish();
            }
        });
    }

    private void loadData() {
        // Here we can use a getById if we had one, but let's use getAllData logic or just query by ID
        // For simplicity, I'll use a raw query or just fetch latest since we passed ID
        android.database.sqlite.SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor res = db.rawQuery("select * from " + DatabaseHelper.TABLE_NAME + " WHERE ID = ?", new String[]{ticketId});

        if (res.moveToFirst()) {
            etSumName.setText(res.getString(1));
            tickets = res.getInt(2);
            type = res.getString(3);
            date = res.getString(4);
            pref = res.getString(5);
            cost = res.getDouble(6);

            StringBuilder details = new StringBuilder();
            details.append("Tickets: ").append(tickets).append("\n");
            details.append("Type: ").append(type).append("\n");
            details.append("Date: ").append(date).append("\n");
            details.append("Preference: ").append(pref).append("\n");
            details.append("Total Cost: ").append(cost);
            tvDetails.setText(details.toString());
        }
        res.close();
    }
}